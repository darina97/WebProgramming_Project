 function myFunction()
{
//Industry
 	var a = document.forms["form"]["Industry"];
	if(a.value=="")
		{
		 alert("Industry Name should not be blank.");
        	 return false;
		}

//Designation
	var b = document.forms["form"]["Designation"];
	if(b.value=="")
		{
		 alert("Designation should not be blank.");
        	 return false;
		}
	
//Package
	var c = document.forms["form"]["Package"];
	if(c.value=="")
		{
		 alert("Package should not be blank.");
        	 return false;
		}
	if(! allnumeric(c))
		{
		 alert("Package in Numbers Only!");
		 return false;
		}

//Name Of Student
	var d = document.forms["form"]["Name Of Student"];
	if(d.value=="")
		{
		 alert("Name should not be blank.");
        	 return false;
		}
	if (! allLetter(d)) 
		{
			 alert("Name should be all characters.");
			 return false;
		}
//Department Of Student
	var e = document.forms["form"]["Department Of Student"];
	if(e.value=="")
		{
		 alert("Department should not be blank.");
        	 return false;
		}
	if (! allLetter(e)) 
		{
			 alert("Department should be all characters.");
			 return false;
		}
//Date of Placement
	var f = document.forms["form"]["Date Of Placement"];
	if(f.value=="")
		{
		 alert("Date should not be blank.");
        	 return false;
		}
	if(! allnumeric(f))
		{
		 alert("Date in Numbers Only!");
	 	 return false;
		}
}

function allLetter(inputtxt)
      {
        var letters = /^[A-Za-z]+$/;
       if(inputtxt.value.match(letters))
       {
       return true;
       }
       else
       {
        return false;
       }
      }
      
function allnumeric(inputtxt)
      {
        var numbers = /^[0-9]+$/;
        if(inputtxt.value.match(numbers))
       {
        return true;
       }
        else
       {
         return false;
       }
      }
