-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2017 at 08:17 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tpo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `ID` int(255) NOT NULL,
  `Industry` varchar(20) NOT NULL,
  `Designation` varchar(20) NOT NULL,
  `Department` varchar(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Package` varchar(20) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`ID`, `Industry`, `Designation`, `Department`, `Name`, `Package`, `Date`) VALUES
(1, 'hvhjh', 'vjhf', 'Computer', 'gfdgd', 'gdfgd', '2017-04-18'),
(2, 'hvhjh', 'vjhf', 'Computer', 'gfdgd', 'gdfgd', '2017-04-18'),
(3, 'godrej', 'graphicdesigner', 'IT', 'Jospeh', '10000', '2017-02-03'),
(4, 'godrej', 'graphic designer', 'IT', 'Joseph dsouza', '10000', '2017-02-03'),
(5, 'godrej', 'graphic designer', 'IT', 'Joseph dsouza', '10000', '2017-02-03'),
(6, 'hgfhgfhgdf', 'graphic designer', 'IT', 'bvjhgfvhbn', '10000', '2017-02-03'),
(7, 'asd ', 'asd asd', 'IT', 'asd asd', '10000', '2017-03-22'),
(8, 'TCS', 'Software analyst', 'IT', 'Atharva Dixit', '340000', '2016-06-23'),
(9, 'asdad', 'analyst', 'IT', 'Joseph dsouza', '10000', '2014-07-25');

-- --------------------------------------------------------

--
-- Table structure for table `notifadd`
--

CREATE TABLE `notifadd` (
  `Sr_No` int(255) NOT NULL,
  `Date` date NOT NULL,
  `Industry` varchar(40) NOT NULL,
  `Designation` varchar(20) NOT NULL,
  `Package` int(30) NOT NULL,
  `Eligible_Branch` varchar(20) NOT NULL,
  `Cut_Off_Criteria` varchar(200) NOT NULL,
  `Additonal_Area` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifadd`
--

INSERT INTO `notifadd` (`Sr_No`, `Date`, `Industry`, `Designation`, `Package`, `Eligible_Branch`, `Cut_Off_Criteria`, `Additonal_Area`) VALUES
(1, '2017-02-23', 'asdasd', 'asdsad', 100000, 'Mechanical', '68.52', 'asdsadsadsd'),
(2, '2017-04-29', 'L&T', 'Analyst', 1000000, 'EXTC', '68.97', 'asdafdzxcxxxdaewddcxxassasasaxzcxzcxcxcxzc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `notifadd`
--
ALTER TABLE `notifadd`
  ADD PRIMARY KEY (`Sr_No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `notifadd`
--
ALTER TABLE `notifadd`
  MODIFY `Sr_No` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
