<!Doctype html>
<html>
<head>
<title>TPO: View Page</title>
<link rel="icon" href="DonBoscoLogo.png" type="image/png">

<img src="DonBosco.png" alt="Don Bosco Institute Of Technology" width='100%' height="142"></img>
<link rel="stylesheet" type="text/css" href="External.css">
<script src="val.js"></script> 

<style>

table

{

	width:100%;

}

table, th, td

{

	border: 1px solid black;

	border-collapse: collapse;

}

th, td

{	

	padding: 5px;

	text-align: center;

}

table#t01 tr:nth-child(even)

{

 	background-color: #fff;
	color: red;

}

table#t01 tr:nth-child(odd)

{

 	background-color: #fff;

}

table#t01 th

{
    
	background-color: #0066ff;

        color: white;

}
	

</style>

</head>
<body>
<h1>TRAINING AND PLACEMENT OFFICE</h1>
    <ul id="m02">
    <li id="m01"><strong><a href="Admission.html">ADMISSIONS</a></strong></li>

    <li id="m01"><strong><a href="View.php">VIEW</a></strong></li>

    <li id="m01"><strong><a href="Notifications.html">NOTIFICATIONS</a></strong></li>

    <li id="m01"><strong><a href="View2.php">VIEW</a></strong></li>

    </ul>
<br>
<br>
<br>
<form name="form" >
<table id="t01">
<?php
echo "JOB REQUIREMENTS";
$conn = new mysqli("localhost","root","","tpo");
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM notifadd";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     echo "<table><tr><th>Date</th><th>Industry</th><th>Designation</th><th>Package</th><th>Eligible_Branch</th><th>Cut-Off_Criteria</th><th>Additonal_Area</th></tr>";
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<tr> <td>" . $row["Date"]. "</td><td>" . $row["Industry"]."</td><td>" . $row["Designation"]. "</td><td>" . $row["Package"]. "</td><td>" . $row["Eligible_Branch"]. "</td><td>" . $row["Cut_Off_Criteria"] ."</td><td>". $row["Additonal_Area"]. "</td></tr>";
     }
     echo "</table>";
} else {
     echo "0 results";
}

$conn->close();
?>

<hr>
<p id="demo"></p>
<footer id="footer">
<script>
      document.getElementById("demo").innerHTML = Date();
</script>
</footer>


</body>

</html>
