<?php

$con= new mysqli("localhost","root","","tpo");

$Date=$_POST['Date'];
$In=$_POST['Industry'];
$Dn=$_POST['Designation'];
$Pkg=$_POST['Package'];
$Br=$_POST['skl'];
$CC=$_POST['Cut-Off_Criteria'];
$AC=$_POST['Additonal_Area'];

$sql= "INSERT INTO Notifadd(Date,Industry,Designation,Package,Eligible_Branch,Cut_Off_Criteria,Additonal_Area) VALUES ('$Date','$In','$Dn','$Pkg','$Br','$CC','$AC')" ;


		if ($con->query($sql) === TRUE){
			echo "Successful";
		}
		else{

			echo "UNSUCCESSFUL";
		}
		
?>
