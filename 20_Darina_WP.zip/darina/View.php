﻿<!DOCTYPE html>

<html>

<head>
<title>TPO: View Page</title>
<link rel="icon" href="DonBoscoLogo.png" type="image/png">

<img src="DonBosco.png" alt="Don Bosco Institute Of Technology" width='100%' height="142"></img>
<link rel="stylesheet" type="text/css" href="External.css">
<script src="val.js"></script> 

<style>

table

{

	width:100%;

}

table, th, td

{

	border: 1px solid black;

	border-collapse: collapse;

}

th, td

{	

	padding: 5px;

	text-align: center;

}

table#t01 tr:nth-child(even)

{

 	background-color: #fff;
	color: red;

}

table#t01 tr:nth-child(odd)

{

 	background-color: #fff;

}

table#t01 th

{
    
	background-color: #0066ff;

        color: white;

}
	

</style>

</head>

<body>
<h1>TRAINING AND PLACEMENT OFFICE</h1>
    <ul id="m02">
    <li id="m01"><strong><a href="Admission.html">ADMISSIONS</a></strong></li>

    <li id="m01"><strong><a href="View.php">VIEW</a></strong></li>

    <li id="m01"><strong><a href="Notifications.html">NOTIFICATIONS</a></strong></li>

    <li id="m01"><strong><a href="View2.php">VIEW</a></strong></li>

    </ul>
<br>
<br>
<br>
<form name="form">
<table id="t01">
<?php
$conn = new mysqli("localhost","root","","tpo");
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT ID, Industry, Designation, Department, Name, Package FROM Admission";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     echo "<table><tr><th>ID</th><th>Industry</th><th>Designation</th><th>Department</th><th>Name</th><th>Package</th></tr>";
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<tr><td>" . $row["ID"]. "</td><td>" . $row["Industry"]."</td><td>" . $row["Designation"]. "</td><td>" . $row["Department"]. "</td><td>" . $row["Name"]. "</td><td>" . $row["Package"]. "</td></tr>";
     }
     echo "</table>";
} else {
     echo "0 results";
}

$conn->close();
?>

<hr>
<p id="demo"></p>
<footer id="footer">
<script>
      document.getElementById("demo").innerHTML = Date();
</script>
</footer>


</body>

</html>
