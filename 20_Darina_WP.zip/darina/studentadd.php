<?php

$con =new mysqli("localhost","root","","tpo");



$In=$_POST['Industry'];
$Dn=$_POST['Designation'];
$Dept=$_POST['Dept'];
$NOS=$_POST['NOS'];
$Pkg=$_POST['Package'];
$DOP=$_POST['DOP'];


$sql = "INSERT INTO admission(Industry,Designation,Department,Name,Package,Date) VALUES('$In','$Dn','$Dept','$NOS','$Pkg','$DOP')";
		
		if ($con->query($sql) === TRUE){
			echo "Successful";
		}
		else{

			echo "UNSUCCESSFUL";
		}
		
?>	
